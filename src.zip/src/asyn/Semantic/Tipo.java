package asyn.Semantic;

public abstract class Tipo extends TipoMetodo{

	public boolean esVoid() {
		return false;
	}

}