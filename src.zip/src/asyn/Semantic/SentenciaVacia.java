package asyn.Semantic;

public class SentenciaVacia extends Sentencia{
	
	public void check() throws Exception{
	}
}