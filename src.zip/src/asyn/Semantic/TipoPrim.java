package asyn.Semantic;

public abstract class TipoPrim extends Tipo{	
}