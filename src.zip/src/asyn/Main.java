package asyn;

import java.io.IOException;
import gci.GenCode;

import exceptions.*;

/**
 * @author Matias Marzullo
 *
 */
public class Main {
	public static void main(String args[]) throws LexicalError, SyntaxError,Exception{
		try {
			if (args.length < 1) {
				System.out.println("Se esperaba un archivo de origen.");
				System.out.println("Use: input [output]");
				return;
			}
			if (args.length > 2) {
				System.out.println("Demasiados argumentos.");
				System.out.println("Use: input [output]");
				return;
			}
			//GenCode.path = "/home/mati/Escritorio/Test/aCorregir/out.ceiasm";
			
			
			GenCode.path = args[0] + ".out.ceiasm";
			
			GenCode.gen();
			//AnalizadorLexico a = new AnalizadorLexico("/home/mati/Escritorio/Test/aCorregir/25_doble_return.mjava");
			AnalizadorLexico a = new AnalizadorLexico(args[0]);
			AnalizadorSyn s= new AnalizadorSyn(a);

			s.analize();
			a.close();
			GenCode.gen().close();

		} catch (IOException e) {
			System.out.println("No se puede abrir el archivo de origen.");
		} 
	}

}