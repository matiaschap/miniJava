package exceptions;

/**
 * @author Matias Marzullo
 *
 */

@SuppressWarnings("serial")

public class ExceptionSem extends Exception {

	public ExceptionSem(String msg) {
		super(msg);
	}

}
